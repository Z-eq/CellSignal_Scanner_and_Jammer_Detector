import unittest
from datetime import datetime
from app import app, db  # import db here
from models import JammingEvent

class TestJammingAlertEndpoint(unittest.TestCase):
    def setUp(self):
        self.client = app.test_client()
        self.db = db

        # Create an application context and create the jamming_events table
        with app.app_context():
            self.db.create_all()  # Use db.create_all() instead of Base.metadata.create_all()

    def tearDown(self):
        # Delete all records from the jamming_events table after each test
        with app.app_context():
            JammingEvent.query.delete()  # Use JammingEvent.query.delete() instead of db.query(JammingEvent).delete()
            self.db.session.commit()

    def test_jamming_alert(self):
        response = self.client.post('/jamming_alert', json={
            "timestamp": datetime.now().timestamp(),  # Use a Unix timestamp
            "current_strength": -80,
            "moving_avg": -30,
            "packet_loss_avg": 0.2
        })

        # Check that the response status code is 200
        self.assertEqual(response.status_code, 200)

        # Check that the response data is as expected
        self.assertEqual(response.get_json(), {"message": "Jamming event saved successfully"})

        # Check that the event was saved to the database
        with app.app_context():
            jamming_event = JammingEvent.query.first()  # Use JammingEvent.query.first() instead of db.query(JammingEvent).first()
            self.assertIsNotNone(jamming_event)
            self.assertEqual(jamming_event.current_strength, -80)
            self.assertEqual(jamming_event.moving_avg, -30)
            self.assertEqual(jamming_event.packet_loss_avg, 0.2)

if __name__ == "__main__":
    unittest.main()

