import requests
import time
import subprocess
import re
import statistics

ssid = "Home24"  # Replace with your Wi-Fi SSID
password = "420KeysOfNeatwork5G"  # Replace with your Wi-Fi password
server_url = "http://192.168.1.237:5000"
interface = "wlan1"  # Replace with the correct Wi-Fi interface name

# Global variables for Wi-Fi jamming detection
window_size = 10
moving_average_window = []

# Global variable for the number of standard deviations for the threshold
threshold_multiplier = 1
def connect_to_wifi(ssid, password):
    print("Connecting to WiFi...")
    # Replace this section with your actual code to connect to Wi-Fi
    # For example, using NetworkManager or other Wi-Fi management tools.
    time.sleep(5)  # Simulating the connection process, adjust this time as needed
    print("Connected to WiFi")

def send_wifi_data_to_server(ssid, address, rssi):
    try:
        response = requests.post(
            f"{server_url}/save",
            headers={'Content-Type': 'application/x-www-form-urlencoded'},
            data={'ssid': ssid, 'address': address, 'rssi': rssi}
        )

        if response.status_code == 200:
            print(response.text)
        else:
            print(f"Error on sending POST: {response.status_code}")
    except requests.exceptions.RequestException as e:
        print(f"Error sending Wi-Fi data to server: {e}")

def send_jamming_alert_to_server(timestamp, current_strength, moving_avg):
    data = {
        'timestamp': timestamp,
        'current_strength': current_strength,
        'moving_avg': moving_avg,
    }
    try:
        response = requests.post(f"{server_url}/jamming_alert", json=data)
        if response.status_code == 200:
            print("Jamming alert sent to server successfully")
        else:
            print(f"Error on sending jamming alert to server: {response.status_code}")
    except requests.exceptions.RequestException as e:
        print(f"Error sending jamming alert to server: {e}")

def get_signal_strength(interface):
    try:
        # Run the iw command to get the signal strength
        output = subprocess.check_output(["iw", interface, "link"]).decode()
        print("IW Output:")
        print(output)

        # Extract the signal strength from the output
        match = re.search(r"signal: (-?\d+) dBm", output)
        if match:
            return int(match.group(1))
        else:
            print("Could not extract signal strength.")
            return None
    except Exception as e:
        print(f"Error getting signal strength: {e}")
        return None

def scan_wifi():
    print("Scanning networks...")
    try:
        scan_output = subprocess.check_output(["sudo", "iwlist", interface, "scan"]).decode("utf-8")
        print("Scan Output:")
        print(scan_output)

        networks = parse_scan(scan_output)

        if len(networks) == 0:
            print("No networks found")
        else:
            print(f"{len(networks)} networks found")
            for i, network in enumerate(networks):
                print(f"{i + 1}: {network['ssid']} ({network['rssi']})")
                send_wifi_data_to_server(network['ssid'], network['address'], network['rssi'])
                time.sleep(0.01)

        time.sleep(5)
    except subprocess.CalledProcessError as e:
        print(f"Error scanning networks: {e}")
    except Exception as e:
        print(f"Unexpected error: {e}")

def parse_scan(scan_output):
    lines = scan_output.split("\n")
    networks = []
    network = {}

    for line in lines:
        if "Cell" in line and network:
            networks.append(network)
            network = {}
        if "ESSID:" in line:
            network['ssid'] = line.split('ESSID:"')[1].split('"')[0]
        if "Address: " in line:
            network['address'] = line.split('Address: ')[1]
        if "Signal level=" in line:
            network['rssi'] = re.findall(r"Signal level=(-?\d+)", line)[0]

    if network:
        networks.append(network)

    return networks

def main():
    try:
        connect_to_wifi(ssid, password)

        while True:
            # Get the current signal strength
            current_strength = get_signal_strength(interface)

            if current_strength is not None:
                print(f"Current Signal Strength: {current_strength} dBm")

                # Update the moving average window
                moving_average_window.append(current_strength)
                if len(moving_average_window) > window_size:
                    moving_average_window.pop(0)

                # Calculate the moving average
                moving_avg = sum(moving_average_window) / len(moving_average_window)
                print(f"Moving Average: {moving_avg:.2f} dBm")

                # Send continuous update to the server
                data = {
                    'current_strength': current_strength,
                    'moving_avg': moving_avg,
                }
                try:
                    response = requests.post(f"{server_url}/continuous_update", json=data)
                    if response.status_code == 200:
                        print("Continuous update sent to server successfully")
                    else:
                        print(f"Error on sending continuous update to server: {response.status_code}")
                except requests.exceptions.RequestException as e:
                    print(f"Error sending continuous update to server: {e}")

                # Check for jamming
                if len(moving_average_window) >= 2:
                    std_dev = statistics.stdev(moving_average_window)
                    threshold = moving_avg - (threshold_multiplier * std_dev)
                    if current_strength < threshold:
                        print("Jamming detected!")
                        timestamp = int(time.time())
                        send_jamming_alert_to_server(timestamp, current_strength, moving_avg)
                    else:
                        print("No jamming detected")
                else:
                    print("Not enough data points for jamming detection.")

            else:
                print("Signal strength not available")

            # Scan for nearby Wi-Fi networks
            scan_wifi()

            # Sleep for 5 seconds before the next iteration
            time.sleep(5)

    except KeyboardInterrupt:
        print("Jammer stopped")

if __name__ == "__main__":
    main()

